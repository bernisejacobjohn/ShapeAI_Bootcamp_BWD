# SHAPEAI Javascript and Reactjs BOOTCAMP
Hi I made this project during the 7 Days Free Bootcamp, conducted by <b> SHAPEAI
</b>.
The instructor during the session was Mr. Shaurya Sinha (Data Analyst Intern at Jio). I got to
learn a lot during these 7 days and it was an amazing experience learning with SHAPEAI.
<br><br>Here's the link for you to watch the sessions as well<br>
<a href="https://www.youtube.com/playlist?list=PL7zl8TDRnbulLetcbkthT0p_IzwgRAYbu"> <img src="https://github.com/ShapeAI/PYTHON-AND-DATA-ANALYTICS/blob/main/YOUTUBE%20THUMBNAIL-4.png"> </a>
<br>I got to have hands on experience on:
<li>JavaScript
<li>HTML
<li>React.js
<br>during these 7 days, and everything was explained from the very basics so that
anyone with zero experience on programming can learn.
I enjoyed these 7 days, you can as well. To register for next free 7 days bootcamp, visit:
<a href="https://www.shapeai.tech"> www.shapeai.tech</a>
or follow SHAPEAI on:
<li><a href=
"https://in.linkedin.com/company/shapeai">LinkedIn</a>
<li><a href=
"https://www.instagram.com/shape.ai/?hl=en">Instagram</a>
<li><a
href=
"https://www.youtube.com/channel/UCTUvDLTW9meuDXWcbmISPdA">YouTu
be</a>
<li><a href=
"https://github.com/shapeai">GitHub</a>
